public class Animal {
}
