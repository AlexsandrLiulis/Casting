public class Cat extends Animal {

    public void destroyWalpapers(){
        System.out.println("Обои уничтожены");
    }
}
